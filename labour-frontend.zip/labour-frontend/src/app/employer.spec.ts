import { Employer } from './employer';

describe('Employer', () => {
  it('should create an instance', () => {
    expect(new Employer()).toBeTruthy();
  });
});
