import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gov-add-contract',
  templateUrl: './gov-add-contract.component.html',
  styleUrls: ['./gov-add-contract.component.css']
})
export class GovAddContractComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
