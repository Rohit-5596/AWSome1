import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddEmployerComponent } from './components/add-employer/add-employer.component';
import { ListEmployerComponent } from './components/list-employer/list-employer.component';
import { UpdateEmployerComponent } from './components/update-employer/update-employer.component';
import { AddContractComponent } from './components/add-contract/add-contract.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddEmployerComponent,
    ListEmployerComponent,
    UpdateEmployerComponent,
    AddContractComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
