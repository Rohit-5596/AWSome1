import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { AddEmployerComponent } from './components/add-employer/add-employer.component';
import { ListEmployerComponent } from './components/list-employer/list-employer.component';
import { AddContractComponent } from './components/add-contract/add-contract.component';


const routes: Routes = [{path : 'add', component:AddEmployerComponent},
{path : '', component:AddContractComponent}
 
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
