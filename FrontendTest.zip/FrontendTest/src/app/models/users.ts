export class Users {
    uid : number;
    password : String;
}
