export class Skillset {
    skillId: number;
    skillType: String;
    minDailyWage: number;
}
