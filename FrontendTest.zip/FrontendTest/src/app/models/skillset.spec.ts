import { Skillset } from './skillset';

describe('Skillset', () => {
  it('should create an instance', () => {
    expect(new Skillset()).toBeTruthy();
  });
});
