export class Employer {

    employerId: number;
    employerName: String;
    address: String;
    city: String;
    state: String;
    pincode: number;
    contactName: String;
    phNo: number;
    businessType: number;
    tanNo: number;
    regnNo:number;
    creationDate: Date;
    lastModifiedDate: Date;

}
