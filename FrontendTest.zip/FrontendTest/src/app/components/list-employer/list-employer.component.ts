import { Component, OnInit } from '@angular/core';
import { EmployerService } from 'src/app/services/employer.service';
import { Employer } from 'src/app/models/employer';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employer',
  templateUrl: './list-employer.component.html',
  styleUrls: ['./list-employer.component.css']
})
export class ListEmployerComponent implements OnInit {

  employer : Observable<Employer[]>;
  constructor(private employerService: EmployerService, private router: Router) { }

  ngOnInit(): void {
    this.employerService.getEmployer().subscribe(data => {this.employer = data; console.log(data)});
  }

  deleteEmployer(id: number)
  {
   // this.router[''];
  }
  editEmployer(id: number)
  {
    
  }


}
