import { Component, OnInit } from '@angular/core';
import { EmployerService } from 'src/app/services/employer.service';
import { Employer } from 'src/app/models/employer';

@Component({
  selector: 'app-update-employer',
  templateUrl: './update-employer.component.html',
  styleUrls: ['./update-employer.component.css']
})
export class UpdateEmployerComponent implements OnInit {

  employer: Employer;
  constructor(employerService: EmployerService) { }

  ngOnInit(): void {
    //this.employerService.getEmployer().subscribe(data => {this.employer = data; console.log(data)});

  }

}
