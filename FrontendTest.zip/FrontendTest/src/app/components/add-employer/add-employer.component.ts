import { Component, OnInit } from '@angular/core';
import { Employer } from 'src/app/models/employer';
import { EmployerService } from 'src/app/services/employer.service';

@Component({
  selector: 'app-add-employer',
  templateUrl: './add-employer.component.html',
  styleUrls: ['./add-employer.component.css']
})
export class AddEmployerComponent implements OnInit {

  employer: Employer = new Employer();
  constructor(private employerService: EmployerService) { }

  ngOnInit() {

  }
  save() {  
    this.employerService.postEmployer(this.employer)  
      .subscribe(data => console.log(data), error => console.log(error));  
    this.employer = new Employer();  
  } 



}
