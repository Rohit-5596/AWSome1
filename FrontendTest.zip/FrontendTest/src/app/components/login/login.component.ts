import { Component, OnInit } from '@angular/core';
import { Users } from 'src/app/models/users';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  uid: number;
  password: string;
  user: Users  ;

  constructor(private router: Router,private loginService: LoginService) { }

  ngOnInit(): void {
  
    this.loginService.getData().subscribe(data => {this.user = data[0]; console.log(this.user)});

    
  

  }

  login(){

    if(this.uid === this.user.uid && this.password === this.user.password){
      alert('logged in successfully');
      this.router.navigate(['/dashboard']);
    }
    else
    {
      console.log("unsuccessfull");
      alert('Invalid credentials');
    }
  }

}
