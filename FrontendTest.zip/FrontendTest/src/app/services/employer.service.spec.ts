import { TestBed } from '@angular/core/testing';

import { EmployerService } from 'src/app/services/employer.service';

describe('AddEmployerService', () => {
  let service: EmployerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
