import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Employer } from '../models/employer';

@Injectable({
  providedIn: 'root'
})
export class EmployerService {
 
  
  baseURL : string = 'http://localhost:1112/LabourMgm';
  emp : Employer;
  constructor(private http: HttpClient) { }

  
  getEmployer() : Observable<any> {
    return this.http.get(this.baseURL + '/Employer/');
}

  postEmployer(employer: Employer) : Observable<any> {
      return this.http.post(this.baseURL + '/Employer/',employer);
  }

  putEmployer(employer: Employer): Observable<any> {
    return this.http.put(this.baseURL + '/Employer/', employer);
  }

  getEmployerById(id: number): Employer {
    return null;
  }

}