import { Injectable } from '@angular/core';
import { Users } from '../models/users';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url: string = '../assets/utilities/UserDetails.json';
  status: string;
  
  constructor(private http: HttpClient) { }

  getData(): Observable<Users[]> {
    return this.http.get<Users[]>(this.url);
  }


}
